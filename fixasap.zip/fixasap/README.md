# FixASAP
 
ITT Lab Project



23/05- Registrations pending(Planned to use two separate database projects using CLoud Firestore, one for partner and one for customer. This would make sign up easier and maintaining the DB is also easier)
