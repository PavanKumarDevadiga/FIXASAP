<html>
<head>
  <body>


<?php
session_start();
$con = mysqli_connect('localhost','root','tiger');
mysqli_select_db($con, 'db_connect');

$add = $_POST['City'];
$emid = $_POST['Email'];
$lname = $_POST['Lname'];
$name = $_POST['Fname'];
$issue = $_POST['comment'];

$State = $_POST['State'];
$Service = $_POST['Service'];
$s = "select * from customer where EMAIL= '$emid'";
$result = mysqli_query($con,$s);
$num = mysqli_num_rows($result);
if($num == 1)
{
  echo"user already updated Issue";
}
else {
  $reg="insert into Customer(FNAME,LNAME,EMAIL,ADDRESS,STATE,SERVICE_TYPE,ISSUE) values ('$name','$lname','$emid','$add','$State','$Service','$issue')";
  mysqli_query($con,$reg);
  echo"Issue updated ,Service Provider will Reach in Shortly";


}

 ?>


</body>
</html>
