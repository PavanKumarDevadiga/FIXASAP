<?php
session_start();
$con = mysqli_connect('localhost','root','tiger');
mysqli_select_db($con, 'db_connect');
$emid = $_POST['Email'];
$add = $_POST['City'];
$phno = $_POST['PhoneNo'];
$lname = $_POST['Lname'];
$name = $_POST['Fname'];
$pass = $_POST['password'];
$s = "select * from Partner where EMAIL= '$emid'";
$result = mysqli_query($con,$s);
$num = mysqli_num_rows($result);
if($num == 1)
{
  echo"user already taken";
}
else {
  $reg="insert into Partner(FNAME,LNAME,EMAIL,ADDRESS,PHONE_NO,PASSWORD) values ('$name','$lname','$emid','$add','$phno','$pass')";
  mysqli_query($con,$reg);
  echo"registration sucsessfull";


}

 ?>
